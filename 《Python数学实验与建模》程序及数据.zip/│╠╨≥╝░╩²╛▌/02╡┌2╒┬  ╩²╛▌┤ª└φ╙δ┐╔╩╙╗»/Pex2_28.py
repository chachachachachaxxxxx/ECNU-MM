#程序文件Pex2_28.py
import os
a=os.listdir("c:\\")      
print(a)     #显示C根目录下的文件和目录列表
print("-------------------------------------")
b=os.listdir(".")         
print(b)     #显示当前工作目录下的文件和目录列表
