#程序文件Pex2_24.py
f=open("Pdata2_12.txt","w")
print("Name of the file:",f.name)
print("Closed or not:",f.closed)
print("Opening mode:",f.mode)
f.close()
