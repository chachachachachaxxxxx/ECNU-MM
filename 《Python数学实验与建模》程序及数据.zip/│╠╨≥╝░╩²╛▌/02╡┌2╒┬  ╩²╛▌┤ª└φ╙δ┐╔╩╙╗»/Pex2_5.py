#程序文件Pex2_5.py
import numpy as np
a=np.array([1,2,3])
print("维度为：",a.shape)    #维度为：（3,)
b=np.array([[1,2,3]])
print("维度为：",b.shape)    #维数为：（1,3）
c=np.array([[1],[2],[3]])
print("维度为：",c.shape)    #维度为：（3,1）
