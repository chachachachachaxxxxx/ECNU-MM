#程序文件FunctionSet.py
def f(x): return x**2+x+1
def g(x): return x**3+2*x+1
def h(x): return 1/f(x)
