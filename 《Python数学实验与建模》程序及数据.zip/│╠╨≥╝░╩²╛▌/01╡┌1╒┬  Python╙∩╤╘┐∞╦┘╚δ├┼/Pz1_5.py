#程序文件Pz1_5.py
print (100>2) and (52>41)  #输出True
total = 124
value = (total % 4 ==0) and (total % 3 == 0)
print(value)     #输出False
