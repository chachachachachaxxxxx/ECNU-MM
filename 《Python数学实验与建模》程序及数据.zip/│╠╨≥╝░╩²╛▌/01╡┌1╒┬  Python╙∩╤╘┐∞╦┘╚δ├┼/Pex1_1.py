#程序文件Pex1_1.py
pi=3.14159
r=float(input("请输入圆的半径："))
print('圆的周长是：',2*pi*r)
