#程序文件Pz1_15.py
def add(a,b): s=sum([a,b]); return (a,b,s)
print("%d加%d的和为%d"%add(10,13))
