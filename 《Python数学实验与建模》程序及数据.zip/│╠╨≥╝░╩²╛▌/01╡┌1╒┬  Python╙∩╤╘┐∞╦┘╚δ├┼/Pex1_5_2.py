#程序文件Pex1_5_2.py
from Pex1_5_1 import *
print(factorial(5))

