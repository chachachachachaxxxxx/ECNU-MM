#程序文件Pz1_6.py
a=5; b=-6
print(~a, bin(~a), bin(b),sep='、')  #输出：-6、-0b110、-0b110
print(5<<2)      #输出：20
print(5>>2)      #输出：1
print(5&3)       #输出：1
print(5|3)       #输出：7
print(5^3)       #输出：6
