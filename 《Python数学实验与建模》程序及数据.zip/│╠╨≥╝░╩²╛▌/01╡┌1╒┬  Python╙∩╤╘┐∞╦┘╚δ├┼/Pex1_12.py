i = 1
sum = 0
while i <= 1000:
    sum = sum+i
    i = i+1
print("sum=", sum)
