#程序文件Pex1_2.py
a, b = eval(input("请输入a,b两个数："))  #把字符串转化为数值
if a>=b: print("最大数为：",a)
else: print("最大数为：",b)
                  
