#程序文件Pex1_11_2.py
from FunctionSet import f, g, h
print(f(1),'\t',g(2),'\t',h(3))
