#程序文件Pex1_11_1.py
import FunctionSet as fs
print(fs.f(1),'\t',fs.g(2),'\t',fs.h(3))
