#程序文件Pex1_5_1.py
def factorial(n):
    r = 1
    while n > 1: r *= n; n -= 1
    return r
