#程序文件Pz1_3.py
name="张三"; age=20
print("%s的年龄是%d"%(name,age))   #输出结果：张三的年龄是20
print("{}的年龄是{}".format(name,age))   #输出结果：张三的年龄是20
