#程序文件Pz1_7.py
print(list(range(5)))       #输出：[0, 1, 2, 3, 4]
print(list(range(1,6)))     #输出：[1, 2, 3, 4, 5]
print(list(range(2,10,2)))  #输出：[2, 4, 6, 8]
