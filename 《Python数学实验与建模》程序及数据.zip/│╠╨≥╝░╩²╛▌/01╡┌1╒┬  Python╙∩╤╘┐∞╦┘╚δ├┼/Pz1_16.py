#程序文件Pz1_16.py
def add(*args): print(args, end=''); s=sum(args); return(s)
print("的和为%d"%add(10,12,6,8))
